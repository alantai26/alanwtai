"""
Quickbase Mock Server (Native API Format)
==========================================
A standalone FastAPI app that mimics Quickbase's native /v1 API endpoints,
returning field-ID-keyed responses just like the real Quickbase API.

Usage:
    1. pip install fastapi uvicorn
    2. python qb_mock_server.py
    3. Set QB_BASE_URL=http://localhost:8100 in your backend .env

Customize the SEED_DATA below to match your testing needs.
"""

import copy
import re
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Any, Optional

# =============================================================================
# FIELD MAPPINGS (must match your backend quickbase_schema.py BiDicts)
# =============================================================================

PO_FIELDS = {
    3: "purchase_order_id",
    1: "date_created",
    1111: "po_number",
    1431: "project",
    1399: "requestor",
    1211: "team",
    1352: "supplier",
    1394: "contact",
    1385: "total_cost",
}

LINE_ITEM_FIELDS = {
    3: "line_item_id",
    1: "date_created",
    6: "line_number",
    15: "po_number",
    60: "spend_category",
    19: "part_number",
    18: "vendor_part_number",
    41: "manufacturer",
    8: "description",
    50: "material",
    9: "unit_of_measure",
    10: "requested_quantity",
    11: "unit_price",
    24: "received_quantity",
}

RECEIPT_FIELDS = {
    3: "receipt_id",
    7: "received_quantity",
    8: "received_notes",
    9: "line_item_id",
}

# Reverse lookups: name -> field_id
PO_REVERSE = {v: k for k, v in PO_FIELDS.items()}
LINE_ITEM_REVERSE = {v: k for k, v in LINE_ITEM_FIELDS.items()}
RECEIPT_REVERSE = {v: k for k, v in RECEIPT_FIELDS.items()}

# =============================================================================
# TABLE IDS - Set these to match your settings.py values
# =============================================================================

PO_TABLE_ID = "po_table"
LINE_ITEMS_TABLE_ID = "li_table"
RECEIPTS_TABLE_ID = "receipts_table"

# =============================================================================
# SEED DATA - Edit these to customize your mock POs and line items
# =============================================================================

SEED_POS: list[dict] = [
    {
        "purchase_order_id": 1001,
        "date_created": "2026-01-05T10:00:00Z",
        "po_number": 50001,
        "project": "Starlink Ground Station",
        "requestor": "Alice Johnson",
        "team": "Hardware Engineering",
        "supplier": "Digi-Key Electronics",
        "contact": "sales@digikey.com",
        "total_cost": 12500.00,
    },
    {
        "purchase_order_id": 1002,
        "date_created": "2026-01-12T14:30:00Z",
        "po_number": 50002,
        "project": "Battery Test Fixture",
        "requestor": "Bob Martinez",
        "team": "Test Engineering",
        "supplier": "McMaster-Carr",
        "contact": None,
        "total_cost": 3200.00,
    },
    {
        "purchase_order_id": 1003,
        "date_created": "2026-01-20T09:00:00Z",
        "po_number": 50003,
        "project": "Thermal Chamber Upgrade",
        "requestor": "Carol Chen",
        "team": "Facilities",
        "supplier": "Grainger",
        "contact": "support@grainger.com",
        "total_cost": 8750.00,
    },
]

SEED_LINE_ITEMS: list[dict] = [
    # PO 50001 line items
    {
        "line_item_id": 2001,
        "date_created": "2026-01-05T10:00:00Z",
        "line_number": "1",
        "po_number": 50001,
        "spend_category": "Electronic Components",
        "part_number": "VIA-RES-100K",
        "vendor_part_number": "RC0805FR-07100KL",
        "manufacturer": "Yageo",
        "description": "100K Ohm 1% 1/8W 0805 SMD Resistor",
        "material": "Thick Film",
        "unit_of_measure": "EA",
        "requested_quantity": 500,
        "received_quantity": 0,
        "unit_price": 0.10,
    },
    {
        "line_item_id": 2002,
        "date_created": "2026-01-05T10:00:00Z",
        "line_number": "2",
        "po_number": 50001,
        "spend_category": "Electronic Components",
        "part_number": "VIA-CAP-10UF",
        "vendor_part_number": "GRM21BR61C106KE15L",
        "manufacturer": "Murata",
        "description": "10uF 16V X5R 0805 Ceramic Capacitor",
        "material": "Ceramic",
        "unit_of_measure": "EA",
        "requested_quantity": 200,
        "received_quantity": 100,
        "unit_price": 0.25,
    },
    {
        "line_item_id": 2003,
        "date_created": "2026-01-05T10:00:00Z",
        "line_number": "3",
        "po_number": 50001,
        "spend_category": "Raw Materials",
        "part_number": "VIA-WIRE-22AWG",
        "vendor_part_number": None,
        "manufacturer": "Alpha Wire",
        "description": "22 AWG Hook-Up Wire, PVC, 300V, Red",
        "material": "Copper / PVC",
        "unit_of_measure": "FT",
        "requested_quantity": 1000,
        "received_quantity": 0,
        "unit_price": 0.15,
    },
    # PO 50002 line items
    {
        "line_item_id": 3001,
        "date_created": "2026-01-12T14:30:00Z",
        "line_number": "1",
        "po_number": 50002,
        "spend_category": "Mechanical Hardware",
        "part_number": "VIA-BOLT-M6X20",
        "vendor_part_number": "91290A315",
        "manufacturer": None,
        "description": "M6 x 20mm Socket Head Cap Screw, Class 12.9",
        "material": "Alloy Steel",
        "unit_of_measure": "EA",
        "requested_quantity": 50,
        "received_quantity": 50,
        "unit_price": 0.42,
    },
    {
        "line_item_id": 3002,
        "date_created": "2026-01-12T14:30:00Z",
        "line_number": "2",
        "po_number": 50002,
        "spend_category": "Mechanical Hardware",
        "part_number": "VIA-ALUM-6061",
        "vendor_part_number": "8975K142",
        "manufacturer": None,
        "description": '6061 Aluminum Sheet, 12" x 12" x 0.25"',
        "material": "Aluminum 6061-T6",
        "unit_of_measure": "EA",
        "requested_quantity": 10,
        "received_quantity": 0,
        "unit_price": 45.00,
    },
    # PO 50003 line items
    {
        "line_item_id": 4001,
        "date_created": "2026-01-20T09:00:00Z",
        "line_number": "1",
        "po_number": 50003,
        "spend_category": "HVAC",
        "part_number": "VIA-HOSE-SILICONE",
        "vendor_part_number": "5236K77",
        "manufacturer": "Parker",
        "description": 'High-Temp Silicone Tubing, 1/2" ID x 3/4" OD',
        "material": "Silicone",
        "unit_of_measure": "FT",
        "requested_quantity": 100,
        "received_quantity": 0,
        "unit_price": 3.50,
    },
]

SEED_RECEIPTS: list[dict] = []

# Auto-incrementing ID for new receipts
_next_receipt_id = 9001

# =============================================================================
# In-memory state
# =============================================================================

pos: list[dict] = []
line_items: list[dict] = []
receipts: list[dict] = []


def _reset_state():
    global pos, line_items, receipts, _next_receipt_id
    pos = copy.deepcopy(SEED_POS)
    line_items = copy.deepcopy(SEED_LINE_ITEMS)
    receipts = copy.deepcopy(SEED_RECEIPTS)
    _next_receipt_id = 9001


_reset_state()

# =============================================================================
# Helpers: convert friendly dicts to Quickbase field-ID format
# =============================================================================


def _to_qb_record(record: dict, field_map: dict[int, str]) -> dict:
    """Convert a friendly-named dict to Quickbase's {field_id: {value: ...}} format."""
    reverse = {v: k for k, v in field_map.items()}
    qb_record = {}
    for name, value in record.items():
        if name in reverse:
            qb_record[str(reverse[name])] = {"value": value}
    return qb_record


def _to_qb_records(records: list[dict], field_map: dict[int, str]) -> list[dict]:
    return [_to_qb_record(r, field_map) for r in records]


# =============================================================================
# Where clause parser
# Handles basic Quickbase where syntax: {field_id.operator.value}
# Supports AND/OR of single clauses
# =============================================================================


def _parse_where(where: str, records: list[dict], field_map: dict[int, str]) -> list[dict]:
    """
    Parse a basic Quickbase where clause and filter records.
    Supports: {fid.EX.value} (exact match)
    Supports AND/OR joining of clauses.
    """
    if not where:
        return records

    # Extract individual clauses: {field_id.operator.value} (value may be quoted)
    clause_pattern = re.compile(r"\{(\d+)\.([\w]+)\.'?([^}']*)'?\}")
    clauses = clause_pattern.findall(where)

    if not clauses:
        return records

    # Determine join type (default AND)
    is_or = "OR" in where.upper()

    def _matches_clause(record: dict, field_id_str: str, operator: str, value: str) -> bool:
        field_id = int(field_id_str)
        field_name = field_map.get(field_id)
        if not field_name:
            return False

        record_value = record.get(field_name)
        op = operator.upper()

        if op == "EX":
            try:
                return float(record_value) == float(value)
            except (ValueError, TypeError):
                return str(record_value) == value

        # Date comparisons: AF (after), BF (before), OAF (on or after), OBF (on or before)
        if op in ("AF", "BF", "OAF", "OBF"):
            try:
                # Strip quotes from value
                clean_value = value.strip("'\"")
                # Parse the filter date (YYYY-MM-DD)
                filter_date = datetime.strptime(clean_value, "%Y-%m-%d")
                # Parse the record date (ISO format)
                if isinstance(record_value, str):
                    record_date = datetime.fromisoformat(record_value.replace("Z", "+00:00")).replace(tzinfo=None)
                else:
                    return False

                if op == "AF":
                    return record_date > filter_date
                elif op == "BF":
                    return record_date < filter_date
                elif op == "OAF":
                    return record_date >= filter_date
                elif op == "OBF":
                    return record_date <= filter_date
            except (ValueError, TypeError):
                return False

        return False

    filtered = []
    for record in records:
        if is_or:
            if any(_matches_clause(record, *c) for c in clauses):
                filtered.append(record)
        else:
            if all(_matches_clause(record, *c) for c in clauses):
                filtered.append(record)

    return filtered


# =============================================================================
# App
# =============================================================================

app = FastAPI(
    title="Quickbase Mock Server (Native Format)",
    description="Mimics Quickbase's /v1 API with field-ID responses. Edit SEED_DATA to customize.",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# Native Quickbase API routes
# =============================================================================


@app.post("/v1/records/query")
async def records_query(request: Request):
    """
    Mimics POST /v1/records/query
    Expects: {"from": table_id, "where": "...", "select": [field_ids]}
    Returns: {"data": [{field_id: {value: ...}, ...}, ...]}
    """
    body = await request.json()
    table_id = body.get("from")
    where = body.get("where")
    select = body.get("select", [])

    if table_id == PO_TABLE_ID:
        filtered = _parse_where(where, pos, PO_FIELDS) if where else pos
        data = _to_qb_records(filtered, PO_FIELDS)

    elif table_id == LINE_ITEMS_TABLE_ID:
        filtered = _parse_where(where, line_items, LINE_ITEM_FIELDS) if where else line_items
        data = _to_qb_records(filtered, LINE_ITEM_FIELDS)

    elif table_id == RECEIPTS_TABLE_ID:
        filtered = _parse_where(where, receipts, RECEIPT_FIELDS) if where else receipts
        data = _to_qb_records(filtered, RECEIPT_FIELDS)

    else:
        raise HTTPException(status_code=404, detail=f"Unknown table: {table_id}")

    # Filter to only selected fields if specified
    if select:
        select_strs = [str(s) for s in select]
        data = [{k: v for k, v in record.items() if k in select_strs} for record in data]

    return {"data": data}


@app.post("/v1/records")
async def create_record(request: Request):
    """
    Mimics POST /v1/records
    Expects: {"to": table_id, "data": [{field_id: {value: ...}, ...}]}
    """
    global _next_receipt_id

    body = await request.json()
    table_id = body.get("to")
    records_data = body.get("data", [])

    if table_id == RECEIPTS_TABLE_ID:
        for qb_record in records_data:
            # Parse the field-ID-keyed record into a friendly dict
            receipt = {"receipt_id": _next_receipt_id}
            _next_receipt_id += 1

            for field_id_str, field_data in qb_record.items():
                field_id = int(field_id_str)
                field_name = RECEIPT_FIELDS.get(field_id)
                if field_name:
                    receipt[field_name] = field_data.get("value")

            receipts.append(receipt)

            # Update received_quantity on the matching line item
            receipt_line_item_id = receipt.get("line_item_id")
            receipt_qty = receipt.get("received_quantity", 0)

            if receipt_line_item_id is not None:
                for li in line_items:
                    if li["line_item_id"] == int(receipt_line_item_id):
                        li["received_quantity"] = (li.get("received_quantity") or 0) + receipt_qty
                        break

        return {"metadata": {"totalNumberOfRecordsProcessed": len(records_data)}}

    raise HTTPException(status_code=400, detail=f"Create not supported for table: {table_id}")


@app.delete("/v1/records")
async def delete_records(request: Request):
    """
    Mimics DELETE /v1/records
    Expects: {"from": table_id, "where": "..."}
    """
    body = await request.json()
    table_id = body.get("from")
    where = body.get("where")

    if table_id == RECEIPTS_TABLE_ID:
        before_count = len(receipts)
        remaining = _parse_where(where, receipts, RECEIPT_FIELDS) if where else []
        to_delete = [r for r in receipts if r not in remaining]

        for r in to_delete:
            receipts.remove(r)

        deleted_count = before_count - len(receipts)
        return {"numberDeleted": deleted_count}

    raise HTTPException(status_code=400, detail=f"Delete not supported for table: {table_id}")


# =============================================================================
# Dev utility routes
# =============================================================================


@app.get("/mock/status")
async def mock_status():
    """Overview of current mock state."""
    return {
        "total_pos": len(pos),
        "total_line_items": len(line_items),
        "total_receipts": len(receipts),
        "purchase_orders": [
            {
                "po_number": po["po_number"],
                "project": po["project"],
                "supplier": po["supplier"],
                "line_item_count": sum(
                    1 for li in line_items if li["po_number"] == po["po_number"]
                ),
            }
            for po in pos
        ],
    }


@app.post("/mock/reset")
async def reset_mock():
    """Reset all mock data back to seed values."""
    _reset_state()
    return {"detail": "Mock data reset to seed values"}


# =============================================================================
# Run
# =============================================================================

PORT = 8100

if __name__ == "__main__":
    import uvicorn

    print(f"\n  Quickbase Mock Server (Native API Format)")
    print(f"  Running on http://localhost:{PORT}")
    print(f"  Swagger docs at http://localhost:{PORT}/docs")
    print(f"\n  Set QB_BASE_URL=http://localhost:{PORT} in your backend .env")
    print(f"\n  Table IDs configured:")
    print(f"    PO table:         {PO_TABLE_ID}")
    print(f"    Line Items table: {LINE_ITEMS_TABLE_ID}")
    print(f"    Receipts table:   {RECEIPTS_TABLE_ID}\n")
    uvicorn.run(app, host="0.0.0.0", port=PORT)